from Tools.Directories import resolveFilename , SCOPE_PLUGINS , fileExists
from enigma import getDesktop
from datetime import datetime



def readFromFile(filename):
	_file = resolveFilename(SCOPE_PLUGINS, "Extensions/MultiStalker/{}".format(filename))
	with open(_file, 'r') as f:
		return f.read()

def log(data):
	now = datetime.now().strftime('%Y-%m-%d %H:%M')
	open('/tmp/MultiSTalker.log', 'a').write(now+' : '+str(data)+'\r\n')

def getDesktopSize():
	s = getDesktop(0).size()
	return (s.width(), s.height())

def isHD():
	desktopSize = getDesktopSize()
	return desktopSize[0] == 1280

def isDreamOS():
	if fileExists('/var/lib/dpkg/status'):
		return True
	else:
		return False