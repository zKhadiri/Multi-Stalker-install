# -*- coding: UTF-8 -*-
from Plugins.Plugin import PluginDescriptor
from Plugins.Extensions.MultiStalker.Stalker import MultiStalker, MultiSTalkerConfig
		
def main(session, **kwargs):
	session.open(MultiStalker)
 
def setup(session, **kwargs):
	session.open(MultiSTalkerConfig)

def Plugins(**kwargs):
	Descriptors=[]
	Descriptors.append(PluginDescriptor(name='Multi-Stalker', description='Multi-Stalker Portal By ZIKO', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main))
	Descriptors.append(PluginDescriptor(name='Multi-Stalker Config', description='Multi-Stalker Config By ZIKO', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=setup))
	return Descriptors